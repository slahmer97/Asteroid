
#ifndef ASTEROID_PARAM_H
#define ASTEROID_PARAM_H

const int LARGEUR = 1000;
const int HAUTEUR = 800;
const int TAILLEF = 20;

#endif //ASTEROID_PARAM_H
